import React from "react";
import styles from "./footer.module.css";

const footer = () => {
  return <footer className={styles.footer}></footer>;
  
};

export default footer;